CREATE TABLE played (
    id INT,
    inning INT,
    over INT,
    ball INT,
    batsman VARCHAR(50),
    non_striker VARCHAR(50),
    bowler VARCHAR(50),
    batsman_runs INT,
    extra_runs INT,
    total_runs INT,
    is_wicket INT, -- Changed to BOOLEAN
    dismissal_kind VARCHAR(50),
    player_dismissed VARCHAR(50),
    fielder VARCHAR(50),
    extras_type VARCHAR(50),
    batting_team VARCHAR(50),
    bowling_team VARCHAR(50)
);

COPY played
FROM 'C:\Program Files\PostgreSQL\16\data\Data_copy\SQL Project/IPL_Ball.csv'
DELIMITER ',' CSV HEADER;

CREATE TABLE ipl_match (
    id BIGINT,
    city VARCHAR(55),
    date DATE,
    player_of_match VARCHAR(55),
    venue VARCHAR(55),
    neutral_venue INT,
    team1 VARCHAR(55),
    team2 VARCHAR(55),
    toss_winner VARCHAR(55),
    toss_decision VARCHAR(55),
    winner VARCHAR(55),
    result VARCHAR(55),
    result_margin BIGINT,
    eliminator VARCHAR(55),
    method VARCHAR(55),
    umpire1 VARCHAR(55),
    umpire2 VARCHAR(55)
);

COPY ipl_match
FROM 'C:\Program Files\PostgreSQL\16\data\Data_copy\SQL Project/IPL_matches.csv'
DELIMITER ',' CSV HEADER;

select * from played;

select * from ipl_match;

/* Task 1 */

SELECT batsman, 
       SUM(batsman_runs) AS runs_scored,
       COUNT(ball) AS balls_faced,
       (SUM(batsman_runs) * 100.0 / COUNT(ball)) AS strike_rate
FROM played 
WHERE batsman_runs > 0  -- Assuming you want to count only runs scored
GROUP BY batsman
HAVING COUNT(ball) > 500
ORDER BY strike_rate DESC LIMIT 10;

/* Task 2 */

select * from ipl_match;

SELECT a.batsman, sum(a.batsman_runs) AS batsman_runs,
sum(a.is_wicket) AS total_dismissals,
ROUND(SUM(a.batsman_runs) * 1.0 / NULLIF(SUM(a.is_wicket), 0), 2) AS batting_average,
COUNT(DISTINCT EXTRACT(YEAR FROM b.date)) AS No_of_Seasons_Played
FROM played AS a
LEFT JOIN
ipl_match AS b ON a.id = b.id
GROUP BY a.batsman
HAVING COUNT(DISTINCT EXTRACT(YEAR FROM b.date)) > 2
ORDER BY batting_average desc limit 10;


/* Task 3 */

select * from played;

    SELECT
    a.batsman,
	sum(a.batsman_runs) as Total_Runs,
    SUM(CASE WHEN a.batsman_runs IN (4, 6) THEN a.batsman_runs ELSE 0 END) AS batsman_boundary_runs,   
	COUNT(DISTINCT EXTRACT(YEAR FROM b.date)) AS No_of_Seasons_Played
FROM
    played AS a
LEFT JOIN
    ipl_match AS b ON a.id = b.id
GROUP BY
    a.batsman
ORDER BY
    batsman_boundary_runs DESC;

-- Create new table using above query "batsman_boundary_runs"

select * from batsman_boundary_runs;

SELECT batsman,total_runs,batsman_boundary_runs,no_of_seasons_played,
       (CAST(batsman_boundary_runs AS FLOAT) / total_runs) * 100 AS boundary_percentage
FROM batsman_boundary_runs
WHERE batsman_boundary_runs != 0 AND total_runs != 0 AND no_of_seasons_played > 2
ORDER BY boundary_percentage DESC LIMIT 10;

/* Task 4 */

SELECT bowler,
	   COUNT(ball) AS balls_bowled,
	   ROUND(COUNT(ball) / 6.0, 2) AS overs,
	   SUM(batsman_runs) AS Bowlers_Expensive,
	   (SUM(batsman_runs) / ROUND(COUNT(ball) / 6.0, 2)) as Economy_of_bowler
FROM played
GROUP BY bowler
HAVING COUNT(ball) > 500
ORDER BY Economy_of_bowler LIMIT 10;

/* Task 5 */
  
SELECT
    bowler,
    COUNT(ball) AS balls_bowled,
    SUM(is_wicket) AS No_of_Wickets_Taken,
    ROUND((COUNT(ball) * 1.0) / SUM(is_wicket), 2) AS Strike_rate_of_bowler
FROM played
GROUP BY bowler
HAVING COUNT(ball) > 500
ORDER BY Strike_rate_of_bowler DESC
LIMIT 10;

/* Task 6 */

-- Creating a table "batsman"

CREATE TABLE batsman AS (SELECT batsman, 
       SUM(batsman_runs) AS runs_scored,
       COUNT(ball) AS balls_faced,
       (SUM(batsman_runs) * 100.0 / COUNT(ball)) AS strike_rate
FROM played 
WHERE batsman_runs > 0  -- Assuming you want to count only runs scored
GROUP BY batsman
HAVING COUNT(ball) > 499
ORDER BY strike_rate DESC);

-- Creating a table "bowlers"

CREATE TABLE bowlers AS (SELECT
    bowler,
    COUNT(ball) AS balls_bowled,
    SUM(is_wicket) AS No_of_Wickets_Taken,
    ROUND((COUNT(ball) * 1.0) / SUM(is_wicket), 2) AS Strike_rate_of_bowler
FROM played
GROUP BY bowler
HAVING COUNT(ball) > 299
ORDER BY Strike_rate_of_bowler DESC);

select * from batsman;

select * from bowlers;


SELECT
  a.batsman as all_rounders,
  a.runs_scored,
  a.strike_rate,
  b.no_of_wickets_taken,
  b.strike_rate_of_bowler
FROM batsman a
JOIN bowlers b ON a.batsman = b.bowler
WHERE a.balls_faced > 499 AND b.balls_bowled > 299
ORDER BY a.strike_rate DESC, b.strike_rate_of_bowler DESC
LIMIT 10;


/* Additional Questions for Final Assessment */

select * from played;
select * from ipl_match;

/* Question 1 */

SELECT 
    A.cities_hosted,
    A.No_of_times_city_hosted,
    B.count_of_cities_hosted_IPL_match
FROM
    (SELECT
        DISTINCT(city) AS cities_hosted,
        COUNT(city) AS No_of_times_city_hosted
    FROM
        ipl_match
    GROUP BY
        city) AS A
LEFT JOIN
    (SELECT
        COUNT(DISTINCT city) AS count_of_cities_hosted_IPL_match
    FROM
        ipl_match) AS B ON 1=1;
		
/* Question 2 */

create table deliveries_v02 as 
select *, case when total_runs >= 4 then 'boundry'
		  	   when total_runs = 0 then 'dot'
			   else 'other' 
			   end as ball_result
from played;

select * from deliveries_v02;
	
/* Question 3 */

SELECT
  COUNT(CASE WHEN ball_result = 'dot' THEN 1 END) AS dot_count,
  COUNT(CASE WHEN ball_result = 'boundry' THEN 1 END) AS boundary_count
FROM deliveries_v02;

/* Question 4 */

SELECT
  batting_team,
  COUNT(CASE WHEN ball_result = 'boundry' THEN 1 END) AS boundary_count_by_each_team
FROM deliveries_v02
GROUP BY batting_team
ORDER BY boundary_count_by_each_team DESC;

/* Question 5 */

SELECT
  batting_team,
  COUNT(CASE WHEN ball_result = 'dot' THEN 1 END) AS dot_count_by_each_team
FROM deliveries_v02
GROUP BY batting_team
ORDER BY dot_count_by_each_team DESC;


/* Question 6 */

SELECT dismissal_kind, COUNT(*) AS total_dismissals
FROM deliveries_v02
WHERE dismissal_kind != 'NA'
GROUP BY dismissal_kind
ORDER BY total_dismissals DESC;

/* Question 7 */

select bowler, sum(extra_runs) as extra_runs
from deliveries_v02
group by bowler
order by extra_runs desc limit 5;

/* Question 8 */

select * from deliveries_v02;

create table deliveries_v03 as (select 
	a.*, 
	b.venue as named_venue,
	b.date as match_date
from deliveries_v02 as a 
left join ipl_match as b on a.id = b.id);

select * from deliveries_v03;

/* Question 9 */

select
	named_venue, sum(total_runs) as total_runs
	from deliveries_v03
group by named_venue
order by total_runs desc;

/* Question 10 */

select
	distinct extract (year from match_date ) as year,
	sum(total_runs) as total_runs,
	named_venue
from deliveries_v03
where named_venue = 'Eden Gardens'
group by year,named_venue
order by total_runs desc;

























